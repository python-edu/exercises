import os
import subprocess
from pathlib import Path
from importlib.resources import files


# global varaiables

FD_NAME = "fd.exe" if os.name == "nt" else "fd"
FD_PATH = files("git_repos").joinpath("bin", FD_NAME)



def git_command(*args: str, pth: Path = None) -> subprocess.CompletedProcess[str]:
    """Run Git in the given directory and return its output and exit code."""
    command = ['git', *args]
    cwd = Path.cwd()
    if pth is not None:
        cwd = str(pth)

    # breakpoint()
    result = subprocess.run(command,
                            cwd=cwd,
                            capture_output=True,
                            text=True
                            )

    return result


def is_repository(pth: Path) -> bool:
    """Check whether the given directory is the top-level Git working tree."""
    args = ("rev-parse", "--show-toplevel")
    info = git_command(*args, pth=pth)

    root = info.stdout.strip()
    if Path(root).resolve() == Path(pth).resolve():
        return True
    else:
        return False


def scan_walk(search_dir: Path | None = None) -> set[Path]:
    """Find Git repositories under a directory using os.walk()."""
    repos = []

    if search_dir is not None:
        search_dir = str(search_dir.strip())
    else:
        search_dir = str(Path.home())

    for directory, subdirectories, files in os.walk(search_dir):
        if ".git" in subdirectories:
            if is_repository(directory):
                repos.append(str(directory).strip())
                subdirectories.clear()  # czyści listę

    return sorted(set(repos))


def scan_fd(search_dir: Path | None = None) -> set[Path]:
    """Search a directory with the bundled fd and return verified Git repository paths."""

    if search_dir is not None:
        search_dir = str(search_dir.strip())
    else:
        search_dir = str(Path.home())

    arguments = [str(FD_PATH), "-H", "-I", "-g", ".git", "--prune", search_dir]
    res = subprocess.run(arguments,
                         capture_output=True,
                         text=True
                         )
    # breakpoint()
    repos = [str(Path(item.strip()).parent) for item in res.stdout.splitlines()]
    repos = sorted(set(repos))
    repos = [pth for pth in repos if is_repository(pth)]

    return repos
